<html lang="en">
<?php include("dbconnect.php"); ?>
 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Two95 International Malaysia Sdn Bhd</title>
    <!-- primary -->
    <link rel="canonical" href=""/> <!--seo-->
    <meta name="description" content=""><!--seo-->
    <meta name="keywords" content=",,,,,,,,,,,,,,,,,,,,,"><!--seo-->
    <!-- bootstrap css js -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- font awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/fontawesome.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/brands.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/solid.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <!-- include styling -->
    <link rel="stylesheet" type="text/css" href="styles/style.css">
	<link rel="stylesheet" type="text/css" href="styles/style1.css">
    <!-- animate on scroll -->
    <!-- animate css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
    <link rel="manifest" href="assets/site.webmanifest">
    <link rel="mask-icon" href="assets/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</head>
<style>
/* Add a black background color to the top navigation */
.topnav {
  position: relative;
  background-color: #F7F9F9;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: black;
  text-align: center;
  padding: 40px 40px;
  text-decoration: none;
  font-size: 18px;                                 <!-- Font size for the navbar -->
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: white;                      <!-- When you hover it -->
  color: blue;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: white;
  color: white;
}

/* Centered section inside the top navigation */            
.topnav-centered a {
  float: none;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/* Right-aligned section inside the top navigation */
.topnav-right {
  float: right;
}

/* Responsive navigation menu - display links on top of each other instead of next to each other (for mobile devices) */
@media screen and (max-width: 600px) {
  .topnav a, .topnav-right {
    float: none;
    display: block;
  }

  .topnav-centered a {
    position: relative;
    top: 0;
    left: 0;
    transform: none;
  }
  .fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}
.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
h1{
  font-size:20px;
}
}
.dropbtn {
  background-color: white;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 250px;
  box-shadow: 0px 8px 20px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 15px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: whilte;}
</style>
<!-- Top navigation -->
<div class="topnav">

  <!-- Centered link -->
  <div class="topnav-centered">
  <a><img src="assets/web_logo_1.png" href="index.php" class="active" width="200" height="100"></a>        <!-- Two95 logo -->
  </div>

  <!-- Left-aligned links (default) -->
 
  <a href="index.php">Home</a>
  <a href="careers.php">Job Seekers</a>
  <a href="employers.php">Employers</a>

  <!-- Right-aligned links -->
<div class="topnav-right">
    <a href="about.php">About Us</a>
    <a href="services.php">Speciality</a>
    <a href="applynow.php">Apply Now</a>     <!-- Submit CV -->
  </div>
</div>
  <!-- Add font awesome icons -->
</div>
</header>
<section class="careers" id="Careers">
      <div class="container">
        <div class="sectiontitle">
          <h3>
            Job Description
          </h3>
        </div>
          <div data-aos="fade-down">
          <div class="row detailcontainer">
            <div class="col-md-4" style="display: flex; text-align: left;">
        <p>Job Description:</p>
          </div>
		  <ul class=" listicon-chevron-right">
		  <li >Strong experience in web and software development.</li>
		  <li >Familiar with the LAMP model and platforms.</li>
		  <li >Experience in practicing good software development disciplines.  It is in your blood to produce work that is not only functional, but easy to use, maintainable, reusable and scalable.</li>
		  <li >Ability to empathize and communicate well with users and stake holders.</li>
		  <li >Strong ability to work independently and multi-task effectively.</li>
		  <li >Adaptable and willing to embrace change in priorities as necessary.</li>
		  <li >Strong attention to detail.</li>
		  <li >Experience in mobile application development is an added advantage.</li>
		  </ul>
		  </div>
		  <div class="row detailcontainer">
          <div class="col-md-4" style="display: flex; text-align: left;">
		  <p>Requirements:</p>
		  </div>
	      </div>
          <ul class=" listicon-chevron-right">
		  <li >Your role is to develop and continuously improve our software with the above in mind.</li>
		  <li >Make our operations more efficient.</li>
		  <li >Enhance and maintain our Customer Relationship Management system.</li>
		  <li >Develop and maintain a content management system for our Resources Library.</li>
		  <li >Create web and mobile applications that can facilitate student engagement and learning.</li>
		  </ul>
		  <h5 style="text-align: left;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading" >
		  <div class="vc_empty_space"   style="height: 32px" >
		  <span class="vc_empty_space_inner"></span>
		  </div>
	      <div class="wpb_text_column wpb_content_element " >
		  <div class="wpb_wrapper">
          <div class="column">
	      </div>
		<h5 style="text-align: left;font-family:Abril Fatface;font-weight:400;font-style:normal" class="vc_custom_heading" >Apply For Job</h5>
		<div role="form" class="wpcf7" id="wpcf7-f583-p584-o1" lang="en-US" dir="ltr">
        <div class="screen-reader-response"></div>
        <form action="#" method="post" class="wpcf7-form" enctype="multipart/form-data" novalidate="novalidate">
        <div style="display: none;">
        <input type="hidden" name="_wpcf7" value="583" />
        <input type="hidden" name="_wpcf7_version" value="5.1.1" />
        <input type="hidden" name="_wpcf7_locale" value="en_US" />
        <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f583-p584-o1" />
        <input type="hidden" name="_wpcf7_container_post" value="584" />
        <input type="hidden" name="g-recaptcha-response" value="" />
        </div>
        <p><label> Name (*)<br />
        <span class="wpcf7-form-control-wrap your-name">
		<input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" id="your-name" aria-required="true" aria-invalid="false" /></span> </label></p>
        <p><label> Email (*)<br />
        <span class="wpcf7-form-control-wrap your-email">
		<input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" id="your-email" aria-required="true" aria-invalid="false" /></span> </label></p>
        <p><label> Phone (*)<br />
        <span class="wpcf7-form-control-wrap your-phone">
		<input type="tel" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" id="your-phone" aria-required="true" aria-invalid="false" /></span></label></p>
        <p><label> Job Position (*)<br />
        <span class="wpcf7-form-control-wrap your-job">
		<input type="text" name="your-job" value=" Business Analyst" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span></label></p>
        <p><label> Cover Letter (*)<br />
        <span class="wpcf7-form-control-wrap your-coverletter">
		<input type="text" name="your-coverletter" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" id="your-coverletter" aria-required="true" aria-invalid="false" /></span> </label></p>
        <p><label> Resume (*)<br />
        <span class="wpcf7-form-control-wrap your-resume">
		<input type="file" name="file" size="40" class="wpcf7-form-control wpcf7-file wpcf7-validates-as-required" id="your-resume"  aria-required="true" aria-invalid="false" /></span></label></p>
        <p><label> Message<br />
        <span class="wpcf7-form-control-wrap your-message">
		<textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" id="your-message" aria-invalid="false"></textarea></span> </label></p>
        <p><input type="submit" name="submit" value="Send" class="wpcf7-form-control wpcf7-submit" /></p>
        <div class="wpcf7-response-output wpcf7-display-none"></div>
		</form>
		</div>
		<div class="vc_empty_space"   style="height: 32px" >
		<span class="vc_empty_space_inner"></span>
		</div>
        </div>
		</div>
		</div>  
<?php
		 if(isset($_POST['submit']))
		{
			$your_name=$_POST['your-name'];
			$your_email=$_POST['your-email'];
			$your_phone=$_POST['your-phone'];
			$your_job=$_POST['your-job'];
			$your_coverletter=$_POST['your-coverletter'];
			$your_message=$_POST['your-message'];
			
			 $filename=addslashes($_FILES["file"]["name"]);$filename1=$_FILES["file"]["name"];
			 $tmpname=addslashes(file_get_contents($_FILES["file"]["tmp_name"]));$tmpname1=$_FILES["file"]["tmp_name"];
			 $filetype=addslashes($_FILES["file"]["type"]);
			 $array=array('jpg','jpeg','png','pdf');
			 $ext=pathinfo($filename,PATHINFO_EXTENSION);
			 move_uploaded_file($tmpname1,"upload/".$filename1);
			 
		 	   if(!empty($filename)){
			if(in_array($ext,$array)){
				mysqli_query($conn,"INSERT INTO business_analyst(your_name,your_email,your_phone,your_job,your_coverletter,your_message,file_name,temp_name) VALUES ('$your_name','$your_email','$your_phone','$your_job','$your_coverletter','$your_message','$filename1','$tmpname1')");
			echo "<script>location.href='careers.php'</script>";
			}
			else{
				echo "unsupported file";
			}
		}else{
			
			echo "please select the image";
		}  
			
		}
		?>
    </section>
	<!-- Footer -->
<footer class="page-footer font-small indigo">

  <!-- Footer Links -->
  <div class="container">

    <!-- Grid row-->
    <div class="row text-center d-flex justify-content-center pt-5 mb-3">

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="team.php">Our Team</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="testimonial.php">Testimonials</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="join.php">Join Us</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="contact.php">Contact</a>
        </h6>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->
    <hr class="rgba-white-light" style="margin: 0 15%;">

    <!-- Grid row-->
    <div class="row d-flex text-center justify-content-center mb-md-0 mb-4">

      <!-- Grid column -->
      <div class="col-md-8 col-12 mt-5">
        <p style="line-height: 1.7rem"></p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->
    <hr class="clearfix d-md-none rgba-silver-light" style="margin: 10% 15% 5%;">

    <!-- Grid row-->
    <div class="row pb-3">

      <!-- Grid column -->
      <div class="col-md-12">

        <div class="mb-5 flex-center">

          <!-- Facebook -->
          <a class="fb-ic">
            <i class="fab fa-facebook-f fa-lg white-text mr-4"> </i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic">
            <i class="fab fa-twitter fa-lg white-text mr-4"> </i>
          </a>
          <!-- Google +-->
          <a class="gplus-ic">
            <i class="fab fa-google-plus-g fa-lg white-text mr-4"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic">
            <i class="fab fa-linkedin-in fa-lg white-text mr-4"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic">
            <i class="fab fa-instagram fa-lg white-text mr-4"> </i>
          </a>
          <!--Pinterest-->
          <a class="pin-ic">
            <i class="fas fa-envelope fa-lg white-text"> </i>
          </a>

        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">©Two95 International Recruitment Agency Sdn. Bhd.
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</body>
</html>