<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<?php include("dbconnect.php"); ?>
<br><br>
<div class="container">
    <div class="row">
         <?php
		$resume_id = $_REQUEST['resume_id'];    /*get user id frm url*/
		
			
		$sql="select * from resume where resume_id='$resume_id'";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_assoc($result);
		?>
		<div class="row">
		<?php
		echo '<iframe src="upload/'.$row['file_name'].'" width="100%" height="800px"></iframe>';
		?>
	</div>
		
	
	   
        </div>
    </div>
</div>

<script>
function myFunction() {
    window.print();
}
</script>