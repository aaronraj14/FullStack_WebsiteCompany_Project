<?php
$host="localhost";
$user="root";    
$password="";         
$database="two95";   

$conn=mysqli_connect($host, $user, $password, $database);
?>