<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Two95 International Malaysia Sdn Bhd</title>
    <!-- primary -->
    <link rel="canonical" href=""/> <!--seo-->
    <meta name="description" content=""><!--seo-->
    <meta name="keywords" content=",,,,,,,,,,,,,,,,,,,,,"><!--seo-->
    <!-- bootstrap css js -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- font awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/fontawesome.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/brands.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/solid.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <!-- include styling -->
    <link rel="stylesheet" type="text/css" href="styles/style.css">
    <!-- animate on scroll -->
    <!-- animate css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
    <link rel="manifest" href="assets/site.webmanifest">
    <link rel="mask-icon" href="assets/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="msapplication-TileColor" content="#F7F9F9">
    <meta name="theme-color" content="#F7F9F9">
</head>
<style>
/* Add a black background color to the top navigation */
.topnav {
  position: relative;
  background-color: #F7F9F9;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: black;
  text-align: center;
  padding: 40px 40px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: white;                      <!-- When you hover it -->
  color: blue;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: white;
  color: white;
}

/* Centered section inside the top navigation */
.topnav-centered a {
  float: none;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/* Right-aligned section inside the top navigation */
.topnav-right {
  float: right;
}

/* Responsive navigation menu - display links on top of each other instead of next to each other (for mobile devices) */
@media screen and (max-width: 600px) {
  .topnav a, .topnav-right {
    float: none;
    display: block;
  }

  .topnav-centered a {
    position: relative;
    top: 0;
    left: 0;
    transform: none;
  }
  .fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}
.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
}
</style>
<!-- Top navigation -->
<div class="topnav">

  <!-- Centered link -->
  <div class="topnav-centered">
   <a><img src="assets/web_logo_1.png" href="index.php" class="active" width="200" height="100"></a>        <!-- Two95 logo -->
  </div>

   <!-- Left-aligned links (default) -->
  <a href="index.php">Home</a>
  <a href="careers.php">Job Seekers</a>
  <a href="employers.php">Employers</a>

  <!-- Right-aligned links -->
  <div class="topnav-right">
    <a href="about.php">About Us</a>
    <a href="services.php">Speciality</a>
    <a href="applynow.php">Apply Now</a>     <!-- Submit CV -->
  </div>
  <!-- Add font awesome icons -->
  

</div>
   <section class="services" id="Services">

      <div class="container">
        <div class="sectiontitle">
        <h3>
          Services
        </h3>
        </div>
       <div class="row" style="padding: 15px;">
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/grain.svg" alt="" style="width: 40px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
           <h5>Agro Business</h5>
          </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/car.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Automobile</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/plane.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Aviation & Aerospace</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/bank.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Banking & Insurance</h5>
           </div>
        </div>
       </div>
       
       <div class="row" style="padding: 15px;">
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/support.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>BPO & KPO</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/support2.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Consumer & Services</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/graduate.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Education</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/marketing.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Media & Marketing</h5>
           </div>
        </div>

      </div>

      <div class="row" style="padding: 15px;">
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/internet.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
           <h5>Information Technology</h5>
          </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/infrastructure.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Infrastructure</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/coal.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Mining & Metals</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/energy.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Power & Energy</h5>
           </div>
        </div>
       </div>
       <div class="row" style="padding: 15px;">
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/smart-cart.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
           <h5>Retailing</h5>
          </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/antenna.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Telecommunication</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/donation.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Not For Profit</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/health.svg" alt="" style="width: 40px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Life Sciences & Healthcare</h5>
           </div>
        </div>
       </div>

       <div class="row" style="padding: 15px;">
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/factory.svg" alt="" style="width: 50px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
           <h5>Manufacturing & Processes</h5>
          </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/meeting.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Financial Services & Consulting</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/statistics.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>Private Equity</h5>
           </div>
        </div>
        <div class="col-md-3 col-6 labels">
          <div class="labelicon">
            <div class="innerlabel">
              <img src="assets/cart-2.svg" alt="" style="width: 35px;" data-aos="zoom-in">
            </div>
          </div>
          <div class="labeltext">
            <h5>E-commerce</h5>
           </div>
        </div>
       </div>
      </div>
    </section>

      <div class="container">
      <div class="row">
        <div class="sectiontitle">
        <h3>
          How it Works?
        </h3>
        </div> 
            <div class="row">
                <div class="col col-3 how-it-works-item no-padding">
                    <div class="col col-tiny-3 no-padding">
                        <img src="https://d3dtv5n1opweh6.cloudfront.net/assets/img/1.svg" alt="Step 1">
                    </div>
                    <div class="col col-tiny-9">
                        <p class="how-it-works-item-text text-dark-gray">
                            <b>Submit your CV or Resume along with a few details about you</b>
                        </p>
                    </div>
                </div>
                <div class="col col-3 how-it-works-item no-padding">
                    <div class="col col-tiny-3 no-padding">
                        <img src="https://d3dtv5n1opweh6.cloudfront.net/assets/img/2.svg" alt="Step 2">
                    </div>
                    <div class="col col-tiny-9">
                        <p class="how-it-works-item-text text-dark-gray">
                            <b>Get matched with recruiters and headhunters</b>
                        </p>
                    </div>
                </div>
                <div class="col col-3 how-it-works-item no-padding">
                    <div class="col col-tiny-3 no-padding">
                        <img src="https://d3dtv5n1opweh6.cloudfront.net/assets/img/3.svg" alt="Step 3">
                    </div>
                    <div class="col col-tiny-9">
                        <p class="how-it-works-item-text text-dark-gray">
                            <b>We deliver your profile to targeted recruitment companies</b>
                        </p>
                    </div>
                </div>
                <div class="col col-3 how-it-works-item no-padding">
                    <div class="col col-tiny-3 no-padding">
                        <img src="https://d3dtv5n1opweh6.cloudfront.net/assets/img/4.svg" alt="Step 4">
                    </div>
                    <div class="col col-tiny-9">
                        <p class="how-it-works-item-text text-dark-gray">
                            <b>View to whom your profile was sent, so you can easily follow up</b>
                        </p>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <br>
    <br>
</div>
<div class="container">
      <div class="row">
        <div class="">
        <h3>
          Three reasons why to use Two95 Recruitment Agency to speed up your job search:
        </h3>
        </div> 
        <div class="reasons clearfix">
            <div class="single-reason">
                <div class="circle-number">
                   
                </div>
                <p>1. We save you time by identifying the quality recruitment agencies relevant to your industry and
                    city.</p>
            </div>
            <div class="single-reason">
                <div class="circle-number">
                    
                </div>
                <p>2. We send your profile in a format that makes it easy and accessible for recruiters to
                    review and match to potential job opportunities.</p>
            </div>
            <div class="single-reason">
                <div class="circle-number">
                    
                </div>
                <p>3. Correspondence from recruiters is sent directly to you so you can pursue opportunities
                    directly.</p>
            </div>
        </div>
    </div>
</div>    
<!-- Footer -->
<footer class="page-footer font-small indigo">

  <!-- Footer Links -->
  <div class="container">

    <!-- Grid row-->
    <div class="row text-center d-flex justify-content-center pt-5 mb-3">

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="team.php">Our Team</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="testimonial.php">Testimonials</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="join.php">Join Us</a>
        </h6>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-3">
        <h6 class="text-uppercase font-weight-bold">
          <a href="contact.php">Contact</a>
        </h6>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->
    <hr class="rgba-white-light" style="margin: 0 15%;">

    <!-- Grid row-->
    <div class="row d-flex text-center justify-content-center mb-md-0 mb-4">

      <!-- Grid column -->
      <div class="col-md-8 col-12 mt-5">
        <p style="line-height: 1.7rem"></p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->
    <hr class="clearfix d-md-none rgba-silver-light" style="margin: 10% 15% 5%;">

    <!-- Grid row-->
    <div class="row pb-3">

      <!-- Grid column -->
      <div class="col-md-12">

        <div class="mb-5 flex-center">

          <!-- Facebook -->
          <a class="fb-ic">
            <i class="fab fa-facebook-f fa-lg white-text mr-4"> </i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic">
            <i class="fab fa-twitter fa-lg white-text mr-4"> </i>
          </a>
          <!-- Google +-->
          <a class="gplus-ic">
            <i class="fab fa-google-plus-g fa-lg white-text mr-4"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic">
            <i class="fab fa-linkedin-in fa-lg white-text mr-4"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic">
            <i class="fab fa-instagram fa-lg white-text mr-4"> </i>
          </a>
          <!--Pinterest-->
          <a class="pin-ic">
            <i class="fas fa-envelope fa-lg white-text"> </i>
          </a>

        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">©Two95 International Recruitment Agency Sdn. Bhd.
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
</section>
</body>
</html>