<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<?php include("dbconnect.php"); ?>
<br><br>
<div class="container">
    <div class="row">
         <?php
		$csid = $_REQUEST['csID']; $job=$_REQUEST['your_job'];   /*get user id frm url*/
		switch($job){
		case "Advertised Manager":	
		$sql="select * from advertised_manager where csID='$csid'";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_assoc($result);
		?>
		<div class="row">
		<?php
 echo '<iframe src="upload/'.$row['file_name'].'" width="100%" height="800px"></iframe>';
	?></div>
		<?php
		break;
		
		case "Analog Engineer":
		$sql1="select * from analog_engineer where csID='$csid'";
		$result1=mysqli_query($conn,$sql1);
		$row1=mysqli_fetch_assoc($result1);
		?>
		<div class="row">
				 <?php 
				  echo '<iframe src="upload/'.$row1['file_name'].'" width="100%" height="800px"></iframe>';
				 ?>
                
            </div>
		<?php
		break;
		
		case " Business Analyst":
		$sql2="select * from business_analyst where csID='$csid'";
		$result2=mysqli_query($conn,$sql2);
		$row2=mysqli_fetch_assoc($result2);
		?>
		<div class="row">
				 <?php  echo '<iframe src="upload/'.$row2['file_name'].'" width="100%" height="800px"></iframe>';?>
                
         </div>
		<?php
		break;
		
		case "Custom Layout Engineer":
		$sql3="select * from custom_layout_engineer where csID='$csid'";
		$result3=mysqli_query($conn,$sql3);
		$row3=mysqli_fetch_assoc($result3);
		?>
		<div class="row">
				 <?php 
				  echo '<iframe src="upload/'.$row3['file_name'].'" width="100%" height="800px"></iframe>';
				 ?>
                
         </div>
		<?php
		break;
		
		case "Software Developer":
		$sql4="select * from software_developer where csID='$csid'";
		$result4=mysqli_query($conn,$sql4);
		$row4=mysqli_fetch_assoc($result4);
		?>
		<div class="row">
				 <?php 
				  echo '<iframe src="upload/'.$row4['file_name'].'" width="100%" height="800px"></iframe>';
				 ?>
                
         </div>
		
		<?php
		break;
		
		case "Customer Service":
		$sql5="select * from customer_service where csID='$csid'";
		$result5=mysqli_query($conn,$sql5);
		$row5=mysqli_fetch_assoc($result5);
		?>
		<div class="row">
				 <?php 
				  echo '<iframe src="upload/'.$row5['file_name'].'" width="100%" height="800px"></iframe>';
				 ?>
                
         </div>
		<?php
		break;
		default:
		echo "invalid";
		}
       ?>		
        </div>
    </div>
</div>

<script>
function myFunction() {
    window.print();
}
</script>